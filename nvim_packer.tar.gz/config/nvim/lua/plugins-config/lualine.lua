-- status line scheme
require('lualine').setup{
	options = { theme = 'papercolor_dark',
		section_separators = '',
		component_separators = ''
	}
}



