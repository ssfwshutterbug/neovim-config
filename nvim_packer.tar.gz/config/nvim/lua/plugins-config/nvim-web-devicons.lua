-- nvim-web-devicons
require'nvim-web-devicons'.get_icon(
	filename, extension, { default = true }
)

