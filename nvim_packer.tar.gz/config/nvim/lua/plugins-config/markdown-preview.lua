-- markdown folding
vim.cmd [[let g:markdown_folding=1]]

