-- code color
vim.cmd("let g:Hexokinase_highlighters = ['sign_column']")

